let campoIdade;
let campoAcao;
let campoCrime;

function setup() {
  createCanvas(800, 400);
  createElement("h2", "Recomendador de filmes");
  createSpan("Sua idade:");
  campoIdade = createInput("5");
  campoAcao = createCheckbox("Gosta de Acao?");
  campoCrime = createCheckbox("Gosta de Crime?");
}

function draw() {
  background("white");
  let idade = campoIdade.value();
  let gostaDeAcao = campoAcao.checked();
  let gostaDeCrime = campoCrime.checked();
  let recomendacao = geraRecomendacao(idade, gostaDeAcao, gostaDeCrime);

  fill(color(76, 0, 115));
  textAlign(CENTER, CENTER);
  textSize(38);
  text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade, gostaDeAcao, gostaDeCrime) {
  if (idade >= 10) {
    if (idade >= 18) {
      return "Clube da Luta";
    } else {
      if (idade >= 16) {
        if(gostaDeAcao || gostaDeCrime) {
          return "Obrigado a matar";          
        } else{
         return "A Origem";
        }
      } else {
        if (gostaDeAcao) {
          return "Homem-Aranha no Aranhaverso";
        } else {
          return "Yu Yu Hakusho: Invasores do Inferno - A Batalha de Meikai";
        }
      }
    }
  } else {
    if (gostaDeAcao) {
      return "Divertidamente";
    } else {
      return "Por Água Abaixo";
    }
  }
}